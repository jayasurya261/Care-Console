import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import ChatBot from '../src/component/ChatBot';

const App = () => {
  return (
    <ChatBot/>
  );
};

export default App;
