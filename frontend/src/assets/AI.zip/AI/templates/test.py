import pandas as pd

# Attempt to read the Parquet file
try:
    df = pd.read_parquet("hf://datasets/ruslanmv/ai-medical-chatbot/dialogues.parquet")
    print("First few rows of the dataset:")
    print(df.head())

    # Function to find the answer to a specific question
    def find_answer(question):
        if 'question' in df.columns and 'answer' in df.columns:
            answer_row = df[df['question'].str.contains(question, case=False, na=False)]
            if not answer_row.empty:
                return answer_row['answer'].values[0]
            else:
                return "Sorry, I couldn't find an answer to that question."
        else:
            return "The dataset doesn't contain 'question' and 'answer' columns."

    # Example question to ask
    question_to_ask = "What are the symptoms of fever?"
    answer = find_answer(question_to_ask)

    # Print the question and answer
    print(f"Question: {question_to_ask}")
    print(f"Answer: {answer}")

except Exception as e:
    print("An error occurred:", e)
